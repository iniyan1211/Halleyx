import express from 'express';
import bcrypt from 'bcryptjs';
import { supabase } from '../config/database.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

// Get all customers (admin only)
router.get('/', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 20, search, status } = req.query;
    
    let query = supabase
      .from('users')
      .select('id, email, first_name, last_name, is_active, created_at, updated_at', { count: 'exact' })
      .eq('role', 'customer');
    
    // Apply search filter
    if (search) {
      query = query.or(`first_name.ilike.%${search}%,last_name.ilike.%${search}%,email.ilike.%${search}%`);
    }
    
    // Apply status filter
    if (status === 'active') {
      query = query.eq('is_active', true);
    } else if (status === 'inactive') {
      query = query.eq('is_active', false);
    }
    
    // Apply sorting and pagination
    query = query.order('created_at', { ascending: false });
    
    const offset = (parseInt(page) - 1) * parseInt(limit);
    query = query.range(offset, offset + parseInt(limit) - 1);
    
    const { data: customers, error, count } = await query;
    
    if (error) {
      console.error('Customers fetch error:', error);
      return res.status(500).json({ error: 'Failed to fetch customers' });
    }
    
    res.json({
      customers,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(count / parseInt(limit)),
        totalItems: count,
        itemsPerPage: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Customers fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single customer (admin only)
router.get('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { data: customer, error } = await supabase
      .from('users')
      .select(`
        id, email, first_name, last_name, is_active, created_at, updated_at,
        orders(
          id, status, total_amount, created_at,
          order_items(
            quantity, unit_price, subtotal,
            product:products(name)
          )
        )
      `)
      .eq('id', req.params.id)
      .eq('role', 'customer')
      .single();
    
    if (error || !customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    
    res.json(customer);
  } catch (error) {
    console.error('Customer fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update customer (admin only)
router.put('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { firstName, lastName, email, isActive } = req.body;
    
    const updateData = {
      updated_at: new Date().toISOString()
    };
    
    if (firstName !== undefined) updateData.first_name = firstName;
    if (lastName !== undefined) updateData.last_name = lastName;
    if (email !== undefined) updateData.email = email.toLowerCase();
    if (isActive !== undefined) updateData.is_active = Boolean(isActive);
    
    const { data: customer, error } = await supabase
      .from('users')
      .update(updateData)
      .eq('id', req.params.id)
      .eq('role', 'customer')
      .select('id, email, first_name, last_name, is_active, created_at, updated_at')
      .single();
    
    if (error) {
      console.error('Customer update error:', error);
      return res.status(500).json({ error: 'Failed to update customer' });
    }
    
    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    
    res.json(customer);
  } catch (error) {
    console.error('Customer update error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Reset customer password (admin only)
router.post('/:id/reset-password', authenticateToken, requireAdmin, async (req, res) => {
  try {
    // Generate temporary password
    const tempPassword = Math.random().toString(36).slice(-12);
    const saltRounds = 12;
    const passwordHash = await bcrypt.hash(tempPassword, saltRounds);
    
    const { data: customer, error } = await supabase
      .from('users')
      .update({
        password_hash: passwordHash,
        updated_at: new Date().toISOString()
      })
      .eq('id', req.params.id)
      .eq('role', 'customer')
      .select('email, first_name, last_name')
      .single();
    
    if (error) {
      console.error('Password reset error:', error);
      return res.status(500).json({ error: 'Failed to reset password' });
    }
    
    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    
    res.json({
      message: 'Password reset successfully',
      temporaryPassword: tempPassword,
      customerEmail: customer.email
    });
  } catch (error) {
    console.error('Password reset error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete customer (admin only)
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    // Check if customer has orders
    const { data: orders, error: orderCheckError } = await supabase
      .from('orders')
      .select('id')
      .eq('customer_id', req.params.id)
      .limit(1);
    
    if (orderCheckError) {
      console.error('Order check error:', orderCheckError);
      return res.status(500).json({ error: 'Failed to check customer dependencies' });
    }
    
    if (orders && orders.length > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete customer with existing orders. Consider deactivating instead.' 
      });
    }
    
    const { data: customer, error } = await supabase
      .from('users')
      .delete()
      .eq('id', req.params.id)
      .eq('role', 'customer')
      .select()
      .single();
    
    if (error) {
      console.error('Customer deletion error:', error);
      return res.status(500).json({ error: 'Failed to delete customer' });
    }
    
    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    
    res.json({ message: 'Customer deleted successfully' });
  } catch (error) {
    console.error('Customer deletion error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;