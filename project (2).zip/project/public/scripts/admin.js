// Admin portal functionality

let currentSection = 'dashboard';
let adminUser = null;

// Check admin authentication on page load
document.addEventListener('DOMContentLoaded', () => {
    const token = getToken();
    const user = getUser();
    
    if (token && user && user.role === 'admin') {
        adminUser = user;
        showAdminDashboard();
        loadDashboardStats();
    } else {
        showAdminLogin();
    }
});

function showAdminLogin() {
    document.getElementById('admin-login').style.display = 'flex';
    document.getElementById('admin-dashboard').style.display = 'none';
}

function showAdminDashboard() {
    document.getElementById('admin-login').style.display = 'none';
    document.getElementById('admin-dashboard').style.display = 'block';
    showSection('dashboard');
}

async function adminLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('admin-email').value;
    const password = document.getElementById('admin-password').value;
    const errorElement = document.getElementById('login-error');
    
    showLoading();
    errorElement.textContent = '';
    
    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password, role: 'admin' })
        });
        
        const data = await response.json();
        
        if (response.ok && data.user.role === 'admin') {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            adminUser = data.user;
            showAdminDashboard();
            loadDashboardStats();
        } else {
            errorElement.textContent = 'Invalid admin credentials';
        }
    } catch (error) {
        errorElement.textContent = 'Network error. Please try again.';
    } finally {
        hideLoading();
    }
}

function showSection(sectionName) {
    // Hide all sections
    document.querySelectorAll('.admin-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(`${sectionName}-section`).classList.add('active');
    
    // Update navigation
    document.querySelectorAll('.admin-nav .nav-link').forEach(link => {
        link.classList.remove('active');
    });
    event.target.classList.add('active');
    
    currentSection = sectionName;
    
    // Load section data
    switch (sectionName) {
        case 'dashboard':
            loadDashboardStats();
            break;
        case 'products':
            loadProducts();
            break;
        case 'customers':
            loadCustomers();
            break;
        case 'orders':
            loadOrders();
            break;
        case 'settings':
            loadSettings();
            break;
    }
}

async function loadDashboardStats() {
    showLoading();
    
    try {
        const response = await fetch('/api/orders/stats/dashboard', {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            const stats = await response.json();
            displayDashboardStats(stats);
        } else {
            throw new Error('Failed to load dashboard stats');
        }
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
        document.getElementById('stats-grid').innerHTML = '<p class="error">Failed to load statistics</p>';
    } finally {
        hideLoading();
    }
}

function displayDashboardStats(stats) {
    const statsGrid = document.getElementById('stats-grid');
    
    statsGrid.innerHTML = `
        <div class="stat-card">
            <h3>${stats.totalProducts}</h3>
            <p>Total Products</p>
        </div>
        <div class="stat-card secondary">
            <h3>${stats.totalCustomers}</h3>
            <p>Total Customers</p>
        </div>
        <div class="stat-card accent">
            <h3>Orders by Status</h3>
            <div class="orders-stats">
                <div class="order-stat pending">
                    <span class="count">${stats.ordersByStatus.pending || 0}</span>
                    <span>Pending</span>
                </div>
                <div class="order-stat processing">
                    <span class="count">${stats.ordersByStatus.processing || 0}</span>
                    <span>Processing</span>
                </div>
                <div class="order-stat shipped">
                    <span class="count">${stats.ordersByStatus.shipped || 0}</span>
                    <span>Shipped</span>
                </div>
                <div class="order-stat delivered">
                    <span class="count">${stats.ordersByStatus.delivered || 0}</span>
                    <span>Delivered</span>
                </div>
                <div class="order-stat cancelled">
                    <span class="count">${stats.ordersByStatus.cancelled || 0}</span>
                    <span>Cancelled</span>
                </div>
            </div>
        </div>
    `;
}

// Products Management
async function loadProducts(page = 1) {
    showLoading();
    
    try {
        const search = document.getElementById('product-search')?.value || '';
        const sort = document.getElementById('product-sort')?.value || 'name-asc';
        
        const params = new URLSearchParams({
            page: page.toString(),
            limit: '20'
        });
        
        if (search) params.append('search', search);
        
        const [sortBy, sortOrder] = sort.split('-');
        params.append('sortBy', sortBy);
        params.append('sortOrder', sortOrder);
        
        const response = await fetch(`/api/products?${params}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayProductsTable(data.products);
            displayProductsPagination(data.pagination);
        } else {
            throw new Error('Failed to load products');
        }
    } catch (error) {
        console.error('Error loading products:', error);
        document.getElementById('products-table-body').innerHTML = '<tr><td colspan="6">Failed to load products</td></tr>';
    } finally {
        hideLoading();
    }
}

function displayProductsTable(products) {
    const tbody = document.getElementById('products-table-body');
    
    tbody.innerHTML = products.map(product => `
        <tr>
            <td title="${product.id}">${product.id.slice(-8)}</td>
            <td>${product.name}</td>
            <td>$${parseFloat(product.price).toFixed(2)}</td>
            <td>
                <span class="${product.stock_quantity === 0 ? 'status-indicator stock-out' : 
                              product.stock_quantity < 10 ? 'status-indicator stock-low' : 
                              'status-indicator stock-available'}">
                    ${product.stock_quantity}
                </span>
            </td>
            <td>
                <span class="status-indicator ${product.is_active ? 'status-active' : 'status-inactive'}">
                    ${product.is_active ? 'Active' : 'Inactive'}
                </span>
            </td>
            <td>
                <div class="table-actions">
                    <button onclick="editProduct('${product.id}')" class="btn btn-sm btn-primary">Edit</button>
                    <button onclick="deleteProduct('${product.id}')" class="btn btn-sm btn-danger">Delete</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function displayProductsPagination(pagination) {
    const container = document.getElementById('products-pagination');
    
    if (pagination.totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let paginationHTML = '<div class="pagination-buttons">';
    
    if (pagination.currentPage > 1) {
        paginationHTML += `<button onclick="loadProducts(${pagination.currentPage - 1})" class="btn btn-outline">Previous</button>`;
    }
    
    for (let i = Math.max(1, pagination.currentPage - 2); i <= Math.min(pagination.totalPages, pagination.currentPage + 2); i++) {
        const activeClass = i === pagination.currentPage ? 'btn-primary' : 'btn-outline';
        paginationHTML += `<button onclick="loadProducts(${i})" class="btn ${activeClass}">${i}</button>`;
    }
    
    if (pagination.currentPage < pagination.totalPages) {
        paginationHTML += `<button onclick="loadProducts(${pagination.currentPage + 1})" class="btn btn-outline">Next</button>`;
    }
    
    paginationHTML += '</div>';
    container.innerHTML = paginationHTML;
}

function showAddProductModal() {
    document.getElementById('product-modal-title').textContent = 'Add Product';
    document.getElementById('product-form').reset();
    document.getElementById('product-form').dataset.productId = '';
    document.getElementById('product-modal').style.display = 'block';
}

async function editProduct(productId) {
    showLoading();
    
    try {
        const response = await fetch(`/api/products/${productId}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            const product = await response.json();
            
            document.getElementById('product-modal-title').textContent = 'Edit Product';
            document.getElementById('product-name').value = product.name;
            document.getElementById('product-description').value = product.description || '';
            document.getElementById('product-price').value = product.price;
            document.getElementById('product-stock').value = product.stock_quantity;
            document.getElementById('product-image').value = product.image_url || '';
            document.getElementById('product-form').dataset.productId = productId;
            document.getElementById('product-modal').style.display = 'block';
        } else {
            throw new Error('Failed to load product');
        }
    } catch (error) {
        console.error('Error loading product:', error);
        alert('Failed to load product details');
    } finally {
        hideLoading();
    }
}

async function saveProduct(event) {
    event.preventDefault();
    
    const form = event.target;
    const productId = form.dataset.productId;
    const isEdit = Boolean(productId);
    
    const productData = {
        name: document.getElementById('product-name').value,
        description: document.getElementById('product-description').value,
        price: parseFloat(document.getElementById('product-price').value),
        stockQuantity: parseInt(document.getElementById('product-stock').value),
        imageUrl: document.getElementById('product-image').value
    };
    
    showLoading();
    
    try {
        const url = isEdit ? `/api/products/${productId}` : '/api/products';
        const method = isEdit ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getToken()}`
            },
            body: JSON.stringify(productData)
        });
        
        if (response.ok) {
            closeModal('product-modal');
            loadProducts();
        } else {
            const data = await response.json();
            alert(data.error || 'Failed to save product');
        }
    } catch (error) {
        console.error('Error saving product:', error);
        alert('Network error. Please try again.');
    } finally {
        hideLoading();
    }
}

async function deleteProduct(productId) {
    if (!confirm('Are you sure you want to delete this product?')) {
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`/api/products/${productId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            loadProducts();
        } else {
            const data = await response.json();
            alert(data.error || 'Failed to delete product');
        }
    } catch (error) {
        console.error('Error deleting product:', error);
        alert('Network error. Please try again.');
    } finally {
        hideLoading();
    }
}

// Customers Management
async function loadCustomers(page = 1) {
    showLoading();
    
    try {
        const search = document.getElementById('customer-search')?.value || '';
        const status = document.getElementById('customer-status')?.value || '';
        
        const params = new URLSearchParams({
            page: page.toString(),
            limit: '20'
        });
        
        if (search) params.append('search', search);
        if (status) params.append('status', status);
        
        const response = await fetch(`/api/customers?${params}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayCustomersTable(data.customers);
            displayCustomersPagination(data.pagination);
        } else {
            throw new Error('Failed to load customers');
        }
    } catch (error) {
        console.error('Error loading customers:', error);
        document.getElementById('customers-table-body').innerHTML = '<tr><td colspan="5">Failed to load customers</td></tr>';
    } finally {
        hideLoading();
    }
}

function displayCustomersTable(customers) {
    const tbody = document.getElementById('customers-table-body');
    
    tbody.innerHTML = customers.map(customer => `
        <tr>
            <td>${customer.first_name} ${customer.last_name}</td>
            <td>${customer.email}</td>
            <td>
                <span class="status-indicator ${customer.is_active ? 'status-active' : 'status-inactive'}">
                    ${customer.is_active ? 'Active' : 'Blocked'}
                </span>
            </td>
            <td>${new Date(customer.created_at).toLocaleDateString()}</td>
            <td>
                <div class="table-actions">
                    <button onclick="viewCustomer('${customer.id}')" class="btn btn-sm btn-primary">View</button>
                    <button onclick="toggleCustomerStatus('${customer.id}', ${!customer.is_active})" 
                            class="btn btn-sm ${customer.is_active ? 'btn-warning' : 'btn-success'}">
                        ${customer.is_active ? 'Block' : 'Unblock'}
                    </button>
                    <button onclick="impersonateCustomer('${customer.id}')" class="btn btn-sm btn-secondary">Impersonate</button>
                    <button onclick="deleteCustomer('${customer.id}')" class="btn btn-sm btn-danger">Delete</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function displayCustomersPagination(pagination) {
    const container = document.getElementById('customers-pagination');
    
    if (pagination.totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let paginationHTML = '<div class="pagination-buttons">';
    
    if (pagination.currentPage > 1) {
        paginationHTML += `<button onclick="loadCustomers(${pagination.currentPage - 1})" class="btn btn-outline">Previous</button>`;
    }
    
    for (let i = Math.max(1, pagination.currentPage - 2); i <= Math.min(pagination.totalPages, pagination.currentPage + 2); i++) {
        const activeClass = i === pagination.currentPage ? 'btn-primary' : 'btn-outline';
        paginationHTML += `<button onclick="loadCustomers(${i})" class="btn ${activeClass}">${i}</button>`;
    }
    
    if (pagination.currentPage < pagination.totalPages) {
        paginationHTML += `<button onclick="loadCustomers(${pagination.currentPage + 1})" class="btn btn-outline">Next</button>`;
    }
    
    paginationHTML += '</div>';
    container.innerHTML = paginationHTML;
}

async function viewCustomer(customerId) {
    showLoading();
    
    try {
        const response = await fetch(`/api/customers/${customerId}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            const customer = await response.json();
            displayCustomerModal(customer);
            document.getElementById('customer-modal').style.display = 'block';
        } else {
            throw new Error('Failed to load customer');
        }
    } catch (error) {
        console.error('Error loading customer:', error);
        alert('Failed to load customer details');
    } finally {
        hideLoading();
    }
}

function displayCustomerModal(customer) {
    const modalBody = document.getElementById('customer-modal-body');
    
    modalBody.innerHTML = `
        <div class="customer-profile">
            <div class="profile-section">
                <h4>Profile Information</h4>
                <div class="profile-info">
                    <div class="info-item">
                        <span class="info-label">Name</span>
                        <span class="info-value">${customer.first_name} ${customer.last_name}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Email</span>
                        <span class="info-value">${customer.email}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Status</span>
                        <span class="info-value">
                            <span class="status-indicator ${customer.is_active ? 'status-active' : 'status-inactive'}">
                                ${customer.is_active ? 'Active' : 'Blocked'}
                            </span>
                        </span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Member Since</span>
                        <span class="info-value">${new Date(customer.created_at).toLocaleDateString()}</span>
                    </div>
                </div>
                <div class="customer-actions">
                    <button onclick="toggleCustomerStatus('${customer.id}', ${!customer.is_active})" 
                            class="btn ${customer.is_active ? 'btn-warning' : 'btn-success'}">
                        ${customer.is_active ? 'Block Customer' : 'Unblock Customer'}
                    </button>
                    <button onclick="resetCustomerPassword('${customer.id}')" class="btn btn-outline">Reset Password</button>
                    <button onclick="impersonateCustomer('${customer.id}')" class="btn btn-secondary">Impersonate</button>
                </div>
            </div>
            
            <div class="profile-section">
                <h4>Order History</h4>
                <div class="order-history">
                    ${customer.orders && customer.orders.length > 0 ? 
                        customer.orders.map(order => `
                            <div class="order-summary">
                                <div>
                                    <div class="order-id">Order #${order.id.slice(-8)}</div>
                                    <div class="order-date">${new Date(order.created_at).toLocaleDateString()}</div>
                                    <span class="status-badge status-${order.status}">${order.status.toUpperCase()}</span>
                                </div>
                                <div class="order-amount">$${parseFloat(order.total_amount).toFixed(2)}</div>
                            </div>
                        `).join('') :
                        '<p>No orders yet</p>'
                    }
                </div>
            </div>
        </div>
    `;
}

async function toggleCustomerStatus(customerId, newStatus) {
    const action = newStatus ? 'unblock' : 'block';
    if (!confirm(`Are you sure you want to ${action} this customer?`)) {
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`/api/customers/${customerId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getToken()}`
            },
            body: JSON.stringify({ isActive: newStatus })
        });
        
        if (response.ok) {
            closeModal('customer-modal');
            loadCustomers();
        } else {
            const data = await response.json();
            alert(data.error || 'Failed to update customer status');
        }
    } catch (error) {
        console.error('Error updating customer status:', error);
        alert('Network error. Please try again.');
    } finally {
        hideLoading();
    }
}

async function resetCustomerPassword(customerId) {
    if (!confirm('Are you sure you want to reset this customer\'s password?')) {
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`/api/customers/${customerId}/reset-password`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            alert(`Password reset successfully!\nTemporary password: ${data.temporaryPassword}\nPlease provide this to the customer: ${data.customerEmail}`);
        } else {
            const data = await response.json();
            alert(data.error || 'Failed to reset password');
        }
    } catch (error) {
        console.error('Error resetting password:', error);
        alert('Network error. Please try again.');
    } finally {
        hideLoading();
    }
}

async function impersonateCustomer(customerId) {
    if (!confirm('Start impersonating this customer? You will be redirected to the customer portal.')) {
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`/api/customers/${customerId}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            const customer = await response.json();
            
            // Store current admin session
            localStorage.setItem('admin-token', getToken());
            localStorage.setItem('admin-user', JSON.stringify(getUser()));
            
            // Store impersonation data
            localStorage.setItem('impersonating', JSON.stringify({
                id: customer.id,
                firstName: customer.first_name,
                lastName: customer.last_name,
                email: customer.email
            }));
            
            // Redirect to customer portal
            window.location.href = '/';
        } else {
            throw new Error('Failed to load customer');
        }
    } catch (error) {
        console.error('Error starting impersonation:', error);
        alert('Failed to start impersonation');
    } finally {
        hideLoading();
    }
}

async function deleteCustomer(customerId) {
    if (!confirm('Are you sure you want to delete this customer? This action cannot be undone.')) {
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`/api/customers/${customerId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            loadCustomers();
        } else {
            const data = await response.json();
            alert(data.error || 'Failed to delete customer');
        }
    } catch (error) {
        console.error('Error deleting customer:', error);
        alert('Network error. Please try again.');
    } finally {
        hideLoading();
    }
}

// Orders Management
async function loadOrders(page = 1) {
    showLoading();
    
    try {
        const status = document.getElementById('order-status')?.value || '';
        const dateFrom = document.getElementById('order-date-from')?.value || '';
        const dateTo = document.getElementById('order-date-to')?.value || '';
        
        const params = new URLSearchParams({
            page: page.toString(),
            limit: '20'
        });
        
        if (status) params.append('status', status);
        if (dateFrom) params.append('dateFrom', dateFrom);
        if (dateTo) params.append('dateTo', dateTo);
        
        const response = await fetch(`/api/orders?${params}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            displayOrdersTable(data.orders);
            displayOrdersPagination(data.pagination);
        } else {
            throw new Error('Failed to load orders');
        }
    } catch (error) {
        console.error('Error loading orders:', error);
        document.getElementById('orders-table-body').innerHTML = '<tr><td colspan="6">Failed to load orders</td></tr>';
    } finally {
        hideLoading();
    }
}

function displayOrdersTable(orders) {
    const tbody = document.getElementById('orders-table-body');
    
    tbody.innerHTML = orders.map(order => `
        <tr>
            <td title="${order.id}">${order.id.slice(-8)}</td>
            <td>${order.customer.first_name} ${order.customer.last_name}</td>
            <td>
                <select onchange="updateOrderStatus('${order.id}', this.value)" class="form-select" style="padding: 4px 8px; font-size: 12px;">
                    <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>Pending</option>
                    <option value="processing" ${order.status === 'processing' ? 'selected' : ''}>Processing</option>
                    <option value="shipped" ${order.status === 'shipped' ? 'selected' : ''}>Shipped</option>
                    <option value="delivered" ${order.status === 'delivered' ? 'selected' : ''}>Delivered</option>
                    <option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                </select>
            </td>
            <td>$${parseFloat(order.total_amount).toFixed(2)}</td>
            <td>${new Date(order.created_at).toLocaleDateString()}</td>
            <td>
                <div class="table-actions">
                    <button onclick="viewOrder('${order.id}')" class="btn btn-sm btn-primary">View</button>
                    <button onclick="deleteOrder('${order.id}')" class="btn btn-sm btn-danger">Delete</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function displayOrdersPagination(pagination) {
    const container = document.getElementById('orders-pagination');
    
    if (pagination.totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let paginationHTML = '<div class="pagination-buttons">';
    
    if (pagination.currentPage > 1) {
        paginationHTML += `<button onclick="loadOrders(${pagination.currentPage - 1})" class="btn btn-outline">Previous</button>`;
    }
    
    for (let i = Math.max(1, pagination.currentPage - 2); i <= Math.min(pagination.totalPages, pagination.currentPage + 2); i++) {
        const activeClass = i === pagination.currentPage ? 'btn-primary' : 'btn-outline';
        paginationHTML += `<button onclick="loadOrders(${i})" class="btn ${activeClass}">${i}</button>`;
    }
    
    if (pagination.currentPage < pagination.totalPages) {
        paginationHTML += `<button onclick="loadOrders(${pagination.currentPage + 1})" class="btn btn-outline">Next</button>`;
    }
    
    paginationHTML += '</div>';
    container.innerHTML = paginationHTML;
}

async function updateOrderStatus(orderId, newStatus) {
    showLoading();
    
    try {
        const response = await fetch(`/api/orders/${orderId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getToken()}`
            },
            body: JSON.stringify({ status: newStatus })
        });
        
        if (response.ok) {
            // No need to reload, status is already updated in UI
        } else {
            const data = await response.json();
            alert(data.error || 'Failed to update order status');
            loadOrders(); // Reload to revert UI changes
        }
    } catch (error) {
        console.error('Error updating order status:', error);
        alert('Network error. Please try again.');
        loadOrders(); // Reload to revert UI changes
    } finally {
        hideLoading();
    }
}

async function viewOrder(orderId) {
    showLoading();
    
    try {
        const response = await fetch(`/api/orders/${orderId}`, {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            const order = await response.json();
            displayOrderModal(order);
            document.getElementById('order-modal').style.display = 'block';
        } else {
            throw new Error('Failed to load order');
        }
    } catch (error) {
        console.error('Error loading order:', error);
        alert('Failed to load order details');
    } finally {
        hideLoading();
    }
}

function displayOrderModal(order) {
    const modalBody = document.getElementById('order-modal-body');
    
    modalBody.innerHTML = `
        <div class="order-details">
            <div class="detail-section">
                <h4>Order Information</h4>
                <div class="profile-info">
                    <div class="info-item">
                        <span class="info-label">Order ID</span>
                        <span class="info-value">${order.id}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Customer</span>
                        <span class="info-value">${order.customer.first_name} ${order.customer.last_name} (${order.customer.email})</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Date</span>
                        <span class="info-value">${new Date(order.created_at).toLocaleDateString()}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Status</span>
                        <span class="info-value">
                            <span class="status-badge status-${order.status}">${order.status.toUpperCase()}</span>
                        </span>
                    </div>
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Items</h4>
                <div class="order-items-detail">
                    ${order.order_items.map(item => `
                        <div class="item-detail">
                            <img src="${item.product.image_url || 'https://via.placeholder.com/60'}" alt="${item.product.name}" class="item-image">
                            <div class="item-info">
                                <span class="item-name">${item.product.name}</span>
                                <span class="item-price">$${parseFloat(item.unit_price).toFixed(2)} x ${item.quantity}</span>
                            </div>
                            <div class="item-total">$${parseFloat(item.subtotal).toFixed(2)}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Shipping Address</h4>
                <div class="address">
                    <p>${order.shipping_address.line1}</p>
                    ${order.shipping_address.line2 ? `<p>${order.shipping_address.line2}</p>` : ''}
                    <p>${order.shipping_address.city}, ${order.shipping_address.state} ${order.shipping_address.zip}</p>
                    <p>${order.shipping_address.country}</p>
                    <p>Phone: ${order.shipping_address.phone}</p>
                </div>
            </div>
            
            <div class="detail-section">
                <div class="order-total-detail">
                    <strong>Total: $${parseFloat(order.total_amount).toFixed(2)}</strong>
                </div>
            </div>
        </div>
    `;
}

async function deleteOrder(orderId) {
    if (!confirm('Are you sure you want to delete this order? This action cannot be undone.')) {
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`/api/orders/${orderId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            loadOrders();
        } else {
            const data = await response.json();
            alert(data.error || 'Failed to delete order');
        }
    } catch (error) {
        console.error('Error deleting order:', error);
        alert('Network error. Please try again.');
    } finally {
        hideLoading();
    }
}

// Settings Management
async function loadSettings() {
    showLoading();
    
    try {
        const response = await fetch('/api/settings', {
            headers: {
                'Authorization': `Bearer ${getToken()}`
            }
        });
        
        if (response.ok) {
            const settings = await response.json();
            if (settings.branding) {
                populateSettingsForm(settings.branding);
            }
        } else {
            throw new Error('Failed to load settings');
        }
    } catch (error) {
        console.error('Error loading settings:', error);
    } finally {
        hideLoading();
    }
}

function populateSettingsForm(branding) {
    document.getElementById('logo-url').value = branding.logo_url || '';
    document.getElementById('primary-color').value = branding.primary_color || '#3B82F6';
    document.getElementById('secondary-color').value = branding.secondary_color || '#14B8A6';
    document.getElementById('font-family').value = branding.font_family || 'Inter';
    document.getElementById('custom-html').value = branding.custom_html || '';
    
    // Update logo preview
    updateLogoPreview();
}

function updateLogoPreview() {
    const logoUrl = document.getElementById('logo-url').value;
    const preview = document.getElementById('logo-preview');
    
    if (logoUrl) {
        preview.innerHTML = `<img src="${logoUrl}" alt="Logo Preview" onerror="this.parentElement.innerHTML='<span class=\\'empty\\'>Invalid image URL</span>'">`;
    } else {
        preview.innerHTML = '<span class="empty">No logo uploaded</span>';
    }
}

async function updateSettings(event) {
    event.preventDefault();
    
    const branding = {
        logo_url: document.getElementById('logo-url').value,
        primary_color: document.getElementById('primary-color').value,
        secondary_color: document.getElementById('secondary-color').value,
        font_family: document.getElementById('font-family').value,
        custom_html: document.getElementById('custom-html').value
    };
    
    showLoading();
    
    try {
        const response = await fetch('/api/settings', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getToken()}`
            },
            body: JSON.stringify({ branding })
        });
        
        if (response.ok) {
            alert('Settings updated successfully!');
        } else {
            const data = await response.json();
            alert(data.error || 'Failed to update settings');
        }
    } catch (error) {
        console.error('Error updating settings:', error);
        alert('Network error. Please try again.');
    } finally {
        hideLoading();
    }
}

// Utility functions
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Add event listeners for logo URL input
document.addEventListener('DOMContentLoaded', () => {
    const logoUrlInput = document.getElementById('logo-url');
    if (logoUrlInput) {
        logoUrlInput.addEventListener('input', updateLogoPreview);
    }
    
    // Add search functionality
    const productSearch = document.getElementById('product-search');
    const customerSearch = document.getElementById('customer-search');
    const orderStatus = document.getElementById('order-status');
    const orderDateFrom = document.getElementById('order-date-from');
    const orderDateTo = document.getElementById('order-date-to');
    const customerStatus = document.getElementById('customer-status');
    const productSort = document.getElementById('product-sort');
    
    if (productSearch) {
        productSearch.addEventListener('input', debounce(() => loadProducts(), 300));
    }
    
    if (customerSearch) {
        customerSearch.addEventListener('input', debounce(() => loadCustomers(), 300));
    }
    
    if (orderStatus) {
        orderStatus.addEventListener('change', () => loadOrders());
    }
    
    if (orderDateFrom) {
        orderDateFrom.addEventListener('change', () => loadOrders());
    }
    
    if (orderDateTo) {
        orderDateTo.addEventListener('change', () => loadOrders());
    }
    
    if (customerStatus) {
        customerStatus.addEventListener('change', () => loadCustomers());
    }
    
    if (productSort) {
        productSort.addEventListener('change', () => loadProducts());
    }
});

// Debounce utility for search inputs
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}