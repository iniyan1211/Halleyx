import express from 'express';
import { supabase } from '../config/database.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

// Get all products (public with optional admin access to inactive)
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 20, search, sortBy = 'name', sortOrder = 'asc' } = req.query;
    
    let query = supabase.from('products').select('*', { count: 'exact' });
    
    // Filter by active status (unless admin)
    const authHeader = req.headers['authorization'];
    let isAdmin = false;
    
    if (authHeader) {
      try {
        const token = authHeader.split(' ')[1];
        const jwt = await import('jsonwebtoken');
        const decoded = jwt.default.verify(token, process.env.JWT_SECRET);
        const { data: user } = await supabase
          .from('users')
          .select('role')
          .eq('id', decoded.userId)
          .single();
        isAdmin = user?.role === 'admin';
      } catch (error) {
        // Not authenticated or invalid token, continue as public user
      }
    }
    
    if (!isAdmin) {
      query = query.eq('is_active', true);
    }
    
    // Apply search filter
    if (search) {
      query = query.ilike('name', `%${search}%`);
    }
    
    // Apply sorting
    const validSortFields = ['name', 'price', 'stock_quantity', 'created_at'];
    const validSortOrders = ['asc', 'desc'];
    
    if (validSortFields.includes(sortBy) && validSortOrders.includes(sortOrder)) {
      query = query.order(sortBy, { ascending: sortOrder === 'asc' });
    }
    
    // Apply pagination
    const offset = (parseInt(page) - 1) * parseInt(limit);
    query = query.range(offset, offset + parseInt(limit) - 1);
    
    const { data: products, error, count } = await query;
    
    if (error) {
      console.error('Products fetch error:', error);
      return res.status(500).json({ error: 'Failed to fetch products' });
    }
    
    res.json({
      products,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(count / parseInt(limit)),
        totalItems: count,
        itemsPerPage: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Products fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single product
router.get('/:id', async (req, res) => {
  try {
    const { data: product, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', req.params.id)
      .single();

    if (error || !product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json(product);
  } catch (error) {
    console.error('Product fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create product (admin only)
router.post('/', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { name, description, price, stockQuantity, imageUrl } = req.body;

    // Validation
    if (!name || !price) {
      return res.status(400).json({ error: 'Name and price are required' });
    }

    if (price <= 0) {
      return res.status(400).json({ error: 'Price must be greater than 0' });
    }

    if (stockQuantity < 0) {
      return res.status(400).json({ error: 'Stock quantity cannot be negative' });
    }

    const { data: product, error } = await supabase
      .from('products')
      .insert([{
        name,
        description: description || '',
        price: parseFloat(price),
        stock_quantity: parseInt(stockQuantity) || 0,
        image_url: imageUrl || ''
      }])
      .select()
      .single();

    if (error) {
      console.error('Product creation error:', error);
      return res.status(500).json({ error: 'Failed to create product' });
    }

    res.status(201).json(product);
  } catch (error) {
    console.error('Product creation error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update product (admin only)
router.put('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { name, description, price, stockQuantity, imageUrl, isActive } = req.body;

    // Validation
    if (price && price <= 0) {
      return res.status(400).json({ error: 'Price must be greater than 0' });
    }

    if (stockQuantity && stockQuantity < 0) {
      return res.status(400).json({ error: 'Stock quantity cannot be negative' });
    }

    const updateData = {
      updated_at: new Date().toISOString()
    };

    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (price !== undefined) updateData.price = parseFloat(price);
    if (stockQuantity !== undefined) updateData.stock_quantity = parseInt(stockQuantity);
    if (imageUrl !== undefined) updateData.image_url = imageUrl;
    if (isActive !== undefined) updateData.is_active = Boolean(isActive);

    const { data: product, error } = await supabase
      .from('products')
      .update(updateData)
      .eq('id', req.params.id)
      .select()
      .single();

    if (error) {
      console.error('Product update error:', error);
      return res.status(500).json({ error: 'Failed to update product' });
    }

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json(product);
  } catch (error) {
    console.error('Product update error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete product (admin only)
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    // Check if product exists in any orders
    const { data: orderItems, error: orderCheckError } = await supabase
      .from('order_items')
      .select('id')
      .eq('product_id', req.params.id)
      .limit(1);

    if (orderCheckError) {
      console.error('Order check error:', orderCheckError);
      return res.status(500).json({ error: 'Failed to check product dependencies' });
    }

    if (orderItems && orderItems.length > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete product that exists in orders. Consider deactivating instead.' 
      });
    }

    const { data: product, error } = await supabase
      .from('products')
      .delete()
      .eq('id', req.params.id)
      .select()
      .single();

    if (error) {
      console.error('Product deletion error:', error);
      return res.status(500).json({ error: 'Failed to delete product' });
    }

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Product deletion error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;