import express from 'express';
import { supabase } from '../config/database.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

// Get settings (public for branding, admin for all)
router.get('/', async (req, res) => {
  try {
    const { data: settings, error } = await supabase
      .from('settings')
      .select('*');

    if (error) {
      console.error('Settings fetch error:', error);
      return res.status(500).json({ error: 'Failed to fetch settings' });
    }

    // Convert to key-value object
    const settingsObj = {};
    settings?.forEach(setting => {
      settingsObj[setting.key] = setting.value;
    });

    res.json(settingsObj);
  } catch (error) {
    console.error('Settings fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update settings (admin only)
router.put('/', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { branding } = req.body;

    if (!branding) {
      return res.status(400).json({ error: 'Branding settings are required' });
    }

    // Validate branding object
    const validKeys = ['logo_url', 'primary_color', 'secondary_color', 'font_family', 'custom_html'];
    const brandingKeys = Object.keys(branding);
    
    for (const key of brandingKeys) {
      if (!validKeys.includes(key)) {
        return res.status(400).json({ error: `Invalid branding key: ${key}` });
      }
    }

    // Update or insert branding settings
    const { data: existingSetting } = await supabase
      .from('settings')
      .select('*')
      .eq('key', 'branding')
      .single();

    let result;
    if (existingSetting) {
      // Update existing
      const { data, error } = await supabase
        .from('settings')
        .update({
          value: branding,
          updated_at: new Date().toISOString()
        })
        .eq('key', 'branding')
        .select()
        .single();
      
      result = { data, error };
    } else {
      // Insert new
      const { data, error } = await supabase
        .from('settings')
        .insert([{
          key: 'branding',
          value: branding
        }])
        .select()
        .single();
      
      result = { data, error };
    }

    if (result.error) {
      console.error('Settings update error:', result.error);
      return res.status(500).json({ error: 'Failed to update settings' });
    }

    res.json({
      message: 'Settings updated successfully',
      branding: result.data.value
    });
  } catch (error) {
    console.error('Settings update error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;