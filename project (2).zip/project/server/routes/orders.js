import express from 'express';
import { supabase } from '../config/database.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

// Get orders (customers see their own, admins see all)
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 20, status, customerId, dateFrom, dateTo } = req.query;
    
    let query = supabase
      .from('orders')
      .select(`
        *,
        customer:users!customer_id(first_name, last_name, email),
        order_items(
          *,
          product:products(name, image_url)
        )
      `, { count: 'exact' });
    
    // Filter by user role
    if (req.user.role === 'customer') {
      query = query.eq('customer_id', req.user.id);
    } else if (customerId) {
      query = query.eq('customer_id', customerId);
    }
    
    // Apply filters
    if (status) {
      query = query.eq('status', status);
    }
    
    if (dateFrom) {
      query = query.gte('created_at', dateFrom);
    }
    
    if (dateTo) {
      query = query.lte('created_at', dateTo);
    }
    
    // Apply sorting and pagination
    query = query.order('created_at', { ascending: false });
    
    const offset = (parseInt(page) - 1) * parseInt(limit);
    query = query.range(offset, offset + parseInt(limit) - 1);
    
    const { data: orders, error, count } = await query;
    
    if (error) {
      console.error('Orders fetch error:', error);
      return res.status(500).json({ error: 'Failed to fetch orders' });
    }
    
    res.json({
      orders,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(count / parseInt(limit)),
        totalItems: count,
        itemsPerPage: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Orders fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single order
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    let query = supabase
      .from('orders')
      .select(`
        *,
        customer:users!customer_id(first_name, last_name, email),
        order_items(
          *,
          product:products(name, image_url, price)
        )
      `)
      .eq('id', req.params.id);
    
    // Filter by user role
    if (req.user.role === 'customer') {
      query = query.eq('customer_id', req.user.id);
    }
    
    const { data: order, error } = await query.single();
    
    if (error || !order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    res.json(order);
  } catch (error) {
    console.error('Order fetch error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create order
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { items, shippingAddress, billingAddress } = req.body;
    
    // Validation
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Order items are required' });
    }
    
    if (!shippingAddress) {
      return res.status(400).json({ error: 'Shipping address is required' });
    }
    
    // Calculate total and validate stock
    let totalAmount = 0;
    const orderItems = [];
    
    for (const item of items) {
      const { data: product, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', item.productId)
        .eq('is_active', true)
        .single();
      
      if (error || !product) {
        return res.status(400).json({ error: `Product ${item.productId} not found` });
      }
      
      if (product.stock_quantity < item.quantity) {
        return res.status(400).json({ 
          error: `Insufficient stock for ${product.name}. Available: ${product.stock_quantity}` 
        });
      }
      
      const subtotal = product.price * item.quantity;
      totalAmount += subtotal;
      
      orderItems.push({
        product_id: product.id,
        quantity: item.quantity,
        unit_price: product.price,
        subtotal: subtotal
      });
    }
    
    // Create order
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert([{
        customer_id: req.user.id,
        total_amount: totalAmount,
        shipping_address: shippingAddress,
        billing_address: billingAddress || shippingAddress,
        status: 'pending'
      }])
      .select()
      .single();
    
    if (orderError) {
      console.error('Order creation error:', orderError);
      return res.status(500).json({ error: 'Failed to create order' });
    }
    
    // Create order items
    const orderItemsWithOrderId = orderItems.map(item => ({
      ...item,
      order_id: order.id
    }));
    
    const { error: itemsError } = await supabase
      .from('order_items')
      .insert(orderItemsWithOrderId);
    
    if (itemsError) {
      console.error('Order items creation error:', itemsError);
      // Rollback order creation
      await supabase.from('orders').delete().eq('id', order.id);
      return res.status(500).json({ error: 'Failed to create order items' });
    }
    
    // Update product stock
    for (const item of items) {
      await supabase
        .from('products')
        .update({ 
          stock_quantity: supabase.raw(`stock_quantity - ${item.quantity}`),
          updated_at: new Date().toISOString()
        })
        .eq('id', item.productId);
    }
    
    // Fetch complete order data
    const { data: completeOrder } = await supabase
      .from('orders')
      .select(`
        *,
        order_items(
          *,
          product:products(name, image_url)
        )
      `)
      .eq('id', order.id)
      .single();
    
    res.status(201).json(completeOrder);
  } catch (error) {
    console.error('Order creation error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update order status (admin only)
router.put('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    
    const validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    
    const { data: order, error } = await supabase
      .from('orders')
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .eq('id', req.params.id)
      .select()
      .single();
    
    if (error) {
      console.error('Order update error:', error);
      return res.status(500).json({ error: 'Failed to update order' });
    }
    
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    res.json(order);
  } catch (error) {
    console.error('Order update error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete order (admin only)
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    // First delete order items
    await supabase
      .from('order_items')
      .delete()
      .eq('order_id', req.params.id);
    
    // Then delete order
    const { data: order, error } = await supabase
      .from('orders')
      .delete()
      .eq('id', req.params.id)
      .select()
      .single();
    
    if (error) {
      console.error('Order deletion error:', error);
      return res.status(500).json({ error: 'Failed to delete order' });
    }
    
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    res.json({ message: 'Order deleted successfully' });
  } catch (error) {
    console.error('Order deletion error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get order statistics (admin only)
router.get('/stats/dashboard', authenticateToken, requireAdmin, async (req, res) => {
  try {
    // Get total counts
    const { data: productCount } = await supabase
      .from('products')
      .select('id', { count: 'exact' })
      .eq('is_active', true);
    
    const { data: customerCount } = await supabase
      .from('users')
      .select('id', { count: 'exact' })
      .eq('role', 'customer')
      .eq('is_active', true);
    
    // Get order counts by status
    const { data: orderStats } = await supabase
      .from('orders')
      .select('status', { count: 'exact' });
    
    const ordersByStatus = {
      pending: 0,
      processing: 0,
      shipped: 0,
      delivered: 0,
      cancelled: 0
    };
    
    if (orderStats) {
      const { data: statusCounts } = await supabase
        .from('orders')
        .select('status')
        .then(({ data }) => {
          const counts = {};
          data?.forEach(order => {
            counts[order.status] = (counts[order.status] || 0) + 1;
          });
          return { data: counts };
        });
      
      Object.assign(ordersByStatus, statusCounts);
    }
    
    res.json({
      totalProducts: productCount?.length || 0,
      totalCustomers: customerCount?.length || 0,
      ordersByStatus
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;