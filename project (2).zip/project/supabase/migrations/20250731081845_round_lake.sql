/*
  # Initial Schema Setup for Halleyx Application

  1. New Tables
    - `users` - Customer and admin user accounts
    - `products` - Product catalog with inventory
    - `orders` - Customer orders
    - `order_items` - Individual items within orders
    - `settings` - Application branding and configuration

  2. Security
    - Enable RLS on all tables
    - Add policies for role-based access control
    - Secure admin and customer data separation

  3. Initial Data
    - Seed admin user with credentials admin@example.com / admin123
    - Sample products for testing
*/

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table for both customers and admins
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  role text NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin')),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price decimal(10,2) NOT NULL CHECK (price > 0),
  stock_quantity integer NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
  image_url text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
  total_amount decimal(10,2) NOT NULL CHECK (total_amount >= 0),
  shipping_address jsonb NOT NULL,
  billing_address jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity integer NOT NULL CHECK (quantity > 0),
  unit_price decimal(10,2) NOT NULL CHECK (unit_price >= 0),
  subtotal decimal(10,2) NOT NULL CHECK (subtotal >= 0),
  created_at timestamptz DEFAULT now()
);

-- Settings table for branding configuration
CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- Users policies
CREATE POLICY "Public can register as customer"
  ON users FOR INSERT
  WITH CHECK (role = 'customer');

CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  TO authenticated
  USING (auth.uid() = id OR EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  TO authenticated
  USING (auth.uid() = id OR EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

-- Products policies
CREATE POLICY "Anyone can view active products"
  ON products FOR SELECT
  USING (is_active = true OR EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Only admins can manage products"
  ON products FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Only admins can update products"
  ON products FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Only admins can delete products"
  ON products FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

-- Orders policies
CREATE POLICY "Customers can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (customer_id = auth.uid() OR EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Customers can create own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = auth.uid() OR EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Only admins can update orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

-- Order items policies
CREATE POLICY "View order items with order access"
  ON order_items FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM orders o
    WHERE o.id = order_id
    AND (o.customer_id = auth.uid() OR EXISTS (
      SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
    ))
  ));

CREATE POLICY "Insert order items with order access"
  ON order_items FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM orders o
    WHERE o.id = order_id
    AND (o.customer_id = auth.uid() OR EXISTS (
      SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
    ))
  ));

-- Settings policies
CREATE POLICY "Anyone can view settings"
  ON settings FOR SELECT
  USING (true);

CREATE POLICY "Only admins can manage settings"
  ON settings FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin'
  ));

-- Insert initial admin user (password: admin123)
INSERT INTO users (email, password_hash, first_name, last_name, role)
VALUES (
  'admin@example.com',
  '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewWjz3sY1YQv3Wl.', -- admin123
  'Admin',
  'User',
  'admin'
) ON CONFLICT (email) DO NOTHING;

-- Insert sample products
INSERT INTO products (name, description, price, stock_quantity, image_url) VALUES
  ('Wireless Headphones', 'High-quality wireless headphones with noise cancellation', 99.99, 50, 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg'),
  ('Smartphone Case', 'Durable protective case for smartphones', 24.99, 100, 'https://images.pexels.com/photos/1618200/pexels-photo-1618200.jpeg'),
  ('Bluetooth Speaker', 'Portable bluetooth speaker with excellent sound quality', 79.99, 30, 'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg'),
  ('Laptop Stand', 'Adjustable aluminum laptop stand for ergonomic working', 45.99, 25, 'https://images.pexels.com/photos/4050299/pexels-photo-4050299.jpeg'),
  ('USB-C Cable', 'Fast charging USB-C cable - 6ft length', 12.99, 200, 'https://images.pexels.com/photos/4792503/pexels-photo-4792503.jpeg'),
  ('Wireless Mouse', 'Ergonomic wireless mouse with precision tracking', 35.99, 75, 'https://images.pexels.com/photos/2115256/pexels-photo-2115256.jpeg'),
  ('Desk Lamp', 'LED desk lamp with adjustable brightness', 59.99, 40, 'https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg'),
  ('Keyboard', 'Mechanical keyboard with backlit keys', 89.99, 60, 'https://images.pexels.com/photos/2115217/pexels-photo-2115217.jpeg'),
  ('Monitor Stand', 'Wooden monitor stand with storage', 39.99, 35, 'https://images.pexels.com/photos/4050300/pexels-photo-4050300.jpeg'),
  ('Cable Organizer', 'Silicone cable management organizer', 15.99, 150, 'https://images.pexels.com/photos/4792832/pexels-photo-4792832.jpeg')
ON CONFLICT DO NOTHING;

-- Insert default branding settings
INSERT INTO settings (key, value) VALUES
  ('branding', '{"logo_url": "", "primary_color": "#3B82F6", "secondary_color": "#14B8A6", "font_family": "Inter", "custom_html": "Welcome to our store! Discover amazing products at great prices."}')
ON CONFLICT (key) DO NOTHING;