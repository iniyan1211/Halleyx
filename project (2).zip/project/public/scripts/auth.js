// Authentication utilities

function getToken() {
    return localStorage.getItem('token');
}

function getUser() {
    const userData = localStorage.getItem('user');
    return userData ? JSON.parse(userData) : null;
}

function isAuthenticated() {
    const token = getToken();
    return token !== null;
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('cart');
    localStorage.removeItem('impersonating');
    window.location.href = '/';
}

function showLoading() {
    const loading = document.getElementById('loading');
    if (loading) {
        loading.style.display = 'flex';
    }
}

function hideLoading() {
    const loading = document.getElementById('loading');
    if (loading) {
        loading.style.display = 'none';
    }
}

function updateAuthUI() {
    const user = getUser();
    const navUser = document.getElementById('nav-user');
    const navAuth = document.getElementById('nav-auth');
    const userName = document.getElementById('user-name');
    
    if (user && navUser && navAuth) {
        navUser.style.display = 'block';
        navAuth.style.display = 'none';
        if (userName) {
            userName.textContent = `${user.firstName} ${user.lastName}`;
        }
    } else if (navUser && navAuth) {
        navUser.style.display = 'none';
        navAuth.style.display = 'flex';
    }
    
    // Check for impersonation mode
    const impersonating = localStorage.getItem('impersonating');
    const impersonationBanner = document.getElementById('impersonation-banner');
    const impersonatedUser = document.getElementById('impersonated-user');
    
    if (impersonating && impersonationBanner && impersonatedUser) {
        const impersonatedData = JSON.parse(impersonating);
        impersonatedUser.textContent = `${impersonatedData.firstName} ${impersonatedData.lastName}`;
        impersonationBanner.style.display = 'block';
        
        // Adjust main content padding
        const mainContent = document.querySelector('.main-content');
        if (mainContent) {
            mainContent.style.paddingTop = '160px';
        }
    } else if (impersonationBanner) {
        impersonationBanner.style.display = 'none';
        
        // Reset main content padding
        const mainContent = document.querySelector('.main-content');
        if (mainContent) {
            mainContent.style.paddingTop = '80px';
        }
    }
}

function exitImpersonation() {
    localStorage.removeItem('impersonating');
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    window.location.href = '/admin';
}

// Initialize auth UI when DOM loads
document.addEventListener('DOMContentLoaded', () => {
    updateAuthUI();
});