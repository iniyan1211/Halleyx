// Main customer portal functionality

let currentPage = 1;
let currentSearch = '';
let currentSort = 'name-asc';

document.addEventListener('DOMContentLoaded', async () => {
    updateAuthUI();
    await loadBrandingSettings();
    await loadProducts();
});

async function loadBrandingSettings() {
    try {
        const response = await fetch('/api/settings');
        if (response.ok) {
            const settings = await response.json();
            if (settings.branding) {
                applyBranding(settings.branding);
            }
        }
    } catch (error) {
        console.error('Error loading branding settings:', error);
    }
}

function applyBranding(branding) {
    // Apply logo
    if (branding.logo_url) {
        const brandLogo = document.getElementById('brand-logo');
        if (brandLogo) {
            brandLogo.src = branding.logo_url;
            brandLogo.style.display = 'block';
        }
    }
    
    // Apply colors
    if (branding.primary_color) {
        document.documentElement.style.setProperty('--primary-color', branding.primary_color);
    }
    
    if (branding.secondary_color) {
        document.documentElement.style.setProperty('--secondary-color', branding.secondary_color);
    }
    
    // Apply font family
    if (branding.font_family) {
        document.documentElement.style.setProperty('--font-family', branding.font_family);
    }
    
    // Apply custom HTML
    if (branding.custom_html) {
        const customMessage = document.getElementById('custom-message');
        if (customMessage) {
            customMessage.innerHTML = branding.custom_html;
        }
    }
}

async function loadProducts(page = 1) {
    showLoading();
    
    try {
        const params = new URLSearchParams({
            page: page.toString(),
            limit: '20'
        });
        
        if (currentSearch) {
            params.append('search', currentSearch);
        }
        
        if (currentSort) {
            const [sortBy, sortOrder] = currentSort.split('-');
            params.append('sortBy', sortBy);
            params.append('sortOrder', sortOrder);
        }
        
        const response = await fetch(`/api/products?${params}`);
        
        if (response.ok) {
            const data = await response.json();
            displayProducts(data.products);
            displayPagination(data.pagination);
            currentPage = page;
        } else {
            throw new Error('Failed to load products');
        }
    } catch (error) {
        console.error('Error loading products:', error);
        document.getElementById('products-grid').innerHTML = '<p class="error">Failed to load products</p>';
    } finally {
        hideLoading();
    }
}

function displayProducts(products) {
    const grid = document.getElementById('products-grid');
    
    if (products.length === 0) {
        grid.innerHTML = '<p class="no-products">No products found</p>';
        return;
    }
    
    grid.innerHTML = products.map(product => `
        <div class="product-card" onclick="showProductModal('${product.id}')">
            <img src="${product.image_url || 'https://via.placeholder.com/280x200'}" 
                 alt="${product.name}" 
                 class="product-image"
                 onerror="this.src='https://via.placeholder.com/280x200'">
            <div class="product-content">
                <h3 class="product-name">${product.name}</h3>
                <p class="product-description">${product.description || ''}</p>
                <p class="product-price">$${parseFloat(product.price).toFixed(2)}</p>
                <p class="product-stock ${getStockClass(product.stock_quantity)}">
                    ${getStockText(product.stock_quantity)}
                </p>
                ${product.stock_quantity > 0 ? 
                    `<button onclick="event.stopPropagation(); addToCartFromCard('${product.id}')" class="btn btn-primary btn-full">Add to Cart</button>` :
                    `<button class="btn btn-outline btn-full" disabled>Out of Stock</button>`
                }
            </div>
        </div>
    `).join('');
}

function getStockClass(stock) {
    if (stock === 0) return 'stock-out';
    if (stock < 10) return 'stock-low';
    return 'stock-available';
}

function getStockText(stock) {
    if (stock === 0) return 'Out of Stock';
    if (stock < 10) return `Only ${stock} left`;
    return 'In Stock';
}

function displayPagination(pagination) {
    const container = document.getElementById('pagination');
    
    if (pagination.totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let paginationHTML = '<div class="pagination-buttons">';
    
    // Previous button
    if (pagination.currentPage > 1) {
        paginationHTML += `<button onclick="loadProducts(${pagination.currentPage - 1})" class="btn btn-outline">Previous</button>`;
    }
    
    // Page numbers
    for (let i = Math.max(1, pagination.currentPage - 2); i <= Math.min(pagination.totalPages, pagination.currentPage + 2); i++) {
        const activeClass = i === pagination.currentPage ? 'btn-primary' : 'btn-outline';
        paginationHTML += `<button onclick="loadProducts(${i})" class="btn ${activeClass}">${i}</button>`;
    }
    
    // Next button
    if (pagination.currentPage < pagination.totalPages) {
        paginationHTML += `<button onclick="loadProducts(${pagination.currentPage + 1})" class="btn btn-outline">Next</button>`;
    }
    
    paginationHTML += '</div>';
    container.innerHTML = paginationHTML;
}

async function addToCartFromCard(productId) {
    try {
        const response = await fetch(`/api/products/${productId}`);
        if (response.ok) {
            const product = await response.json();
            addToCart(product, 1);
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
    }
}

async function showProductModal(productId) {
    showLoading();
    
    try {
        const response = await fetch(`/api/products/${productId}`);
        if (response.ok) {
            const product = await response.json();
            displayProductModal(product);
            document.getElementById('product-modal').style.display = 'block';
        } else {
            throw new Error('Failed to load product details');
        }
    } catch (error) {
        console.error('Error loading product:', error);
        alert('Failed to load product details');
    } finally {
        hideLoading();
    }
}

function displayProductModal(product) {
    const modalBody = document.getElementById('product-modal-body');
    
    modalBody.innerHTML = `
        <div class="product-modal-content">
            <div class="product-modal-image">
                <img src="${product.image_url || 'https://via.placeholder.com/400x300'}" 
                     alt="${product.name}"
                     onerror="this.src='https://via.placeholder.com/400x300'">
            </div>
            <div class="product-modal-details">
                <h2>${product.name}</h2>
                <p class="product-price">$${parseFloat(product.price).toFixed(2)}</p>
                <p class="product-stock ${getStockClass(product.stock_quantity)}">
                    ${getStockText(product.stock_quantity)}
                </p>
                <p class="product-description">${product.description || 'No description available.'}</p>
                
                ${product.stock_quantity > 0 ? `
                    <div class="quantity-selector">
                        <label for="quantity">Quantity:</label>
                        <select id="quantity" class="form-select" style="width: auto; display: inline-block; margin-left: 10px;">
                            ${Array.from({length: Math.min(product.stock_quantity, 10)}, (_, i) => 
                                `<option value="${i + 1}">${i + 1}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <button onclick="addToCartFromModal('${product.id}')" class="btn btn-primary btn-lg">
                        Add to Cart
                    </button>
                ` : `
                    <button class="btn btn-outline btn-lg" disabled>Out of Stock</button>
                `}
            </div>
        </div>
    `;
}

async function addToCartFromModal(productId) {
    const quantity = parseInt(document.getElementById('quantity').value);
    
    try {
        const response = await fetch(`/api/products/${productId}`);
        if (response.ok) {
            const product = await response.json();
            addToCart(product, quantity);
            closeProductModal();
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
    }
}

function closeProductModal() {
    document.getElementById('product-modal').style.display = 'none';
}

function searchProducts() {
    currentSearch = document.getElementById('search-input').value;
    currentPage = 1;
    loadProducts(1);
}

function sortProducts() {
    currentSort = document.getElementById('sort-select').value;
    currentPage = 1;
    loadProducts(1);
}

// Handle Enter key in search input
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });
    }
});

// Add product modal styles
const modalStyles = `
    .product-modal-content {
        display: flex;
        gap: 2rem;
        max-width: 800px;
    }
    
    .product-modal-image {
        flex: 1;
    }
    
    .product-modal-image img {
        width: 100%;
        height: auto;
        border-radius: 8px;
    }
    
    .product-modal-details {
        flex: 1;
    }
    
    .product-modal-details h2 {
        margin-bottom: 1rem;
    }
    
    .product-modal-details .product-price {
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--primary-color);
        margin-bottom: 0.5rem;
    }
    
    .product-modal-details .product-description {
        margin: 1rem 0;
        line-height: 1.6;
    }
    
    .quantity-selector {
        margin: 1.5rem 0;
        display: flex;
        align-items: center;
    }
    
    .quantity-selector label {
        font-weight: 500;
    }
    
    @media (max-width: 768px) {
        .product-modal-content {
            flex-direction: column;
        }
    }
`;

// Add styles to head
const styleSheet = document.createElement('style');
styleSheet.textContent = modalStyles;
document.head.appendChild(styleSheet);